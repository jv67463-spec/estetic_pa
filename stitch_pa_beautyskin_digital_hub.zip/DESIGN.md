---
name: L'Atelier de Beauté
colors:
  surface: '#faf9f6'
  surface-dim: '#dbdad7'
  surface-bright: '#faf9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f1'
  surface-container: '#efeeeb'
  surface-container-high: '#e9e8e5'
  surface-container-highest: '#e3e2e0'
  on-surface: '#1a1c1a'
  on-surface-variant: '#444748'
  inverse-surface: '#2f312f'
  inverse-on-surface: '#f2f1ee'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#5f5e5b'
  on-secondary: '#ffffff'
  secondary-container: '#e5e2dd'
  on-secondary-container: '#656461'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1d1c17'
  on-tertiary-container: '#87837d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474746'
  secondary-fixed: '#e5e2dd'
  secondary-fixed-dim: '#c9c6c2'
  on-secondary-fixed: '#1c1c19'
  on-secondary-fixed-variant: '#474743'
  tertiary-fixed: '#e7e2da'
  tertiary-fixed-dim: '#cac6be'
  on-tertiary-fixed: '#1d1c17'
  on-tertiary-fixed-variant: '#494741'
  background: '#faf9f6'
  on-background: '#1a1c1a'
  surface-variant: '#e3e2e0'
typography:
  display-xl:
    fontFamily: Bodoni Moda
    fontSize: 64px
    fontWeight: '400'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Bodoni Moda
    fontSize: 40px
    fontWeight: '400'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Bodoni Moda
    fontSize: 32px
    fontWeight: '400'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Bodoni Moda
    fontSize: 28px
    fontWeight: '400'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  margin-desktop: 80px
  margin-mobile: 24px
  gutter: 24px
  stack-xl: 120px
  stack-lg: 64px
  stack-md: 32px
  stack-sm: 16px
---

## Brand & Style
The brand personality is rooted in "Quiet Luxury"—it is sophisticated, intentional, and serene. It targets a discerning clientele seeking professional beauty services in an environment that feels like a private sanctuary. 

The visual style is **High-End Minimalism** with an **Editorial** edge. It mimics the layout of a premium fashion magazine: prioritize generous whitespace, precise alignment, and a strict "less is more" philosophy. The emotional response should be an immediate sense of calm and trust, conveyed through a muted palette and razor-sharp typography.

## Colors
The palette is a curated selection of "Skin Neutrals." 

- **Primary (Deep Charcoal/Black):** Used exclusively for typography and high-impact accents to provide grounding and authority.
- **Secondary (Warm Sand):** Used for primary backgrounds and large surface areas to evoke a sense of warmth and skin-like texture.
- **Tertiary (Muted Stone):** Used for subtle UI differentiation, such as dividers, borders, and disabled states.
- **Neutral (Off-White/Cream):** The canvas color for the entire system, ensuring the UI feels airy and clean.

## Typography
The typography pairing contrasts historical elegance with modern precision. 

- **Bodoni Moda** is used for all headlines and display text. Its high-contrast strokes and vertical stress communicate luxury and editorial fashion.
- **Hanken Grotesk** provides a clean, highly legible foundation for all functional text and body copy. 
- **Usage Note:** Large display text should often be centered to emphasize the "studio" feel. Labels should use uppercase with generous letter spacing to act as structural markers.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy on desktop to ensure a curated, "gallery-like" presentation.

- **Desktop (1440px+):** 12-column grid with wide 80px side margins. Content should be allowed to "breathe" with massive vertical gaps (`stack-xl`) between sections.
- **Mobile:** 4-column grid with 24px margins. Layouts should stack vertically, maintaining a single-column focus to preserve the minimalist aesthetic.
- **Spacing Rhythm:** Use 8px increments, but prioritize large-scale negative space. Elements should never feel crowded; if in doubt, increase the padding.

## Elevation & Depth
This design system avoids traditional shadows to maintain its high-end, flat editorial look. Depth is instead achieved through:

- **Tonal Layering:** Using different shades of neutrals (Cream vs. Stone) to separate content sections.
- **Thin Outlines:** Using 0.5px or 1px borders in the tertiary color to define interactive zones without adding visual weight.
- **Backdrop Blurs:** For navigation overlays, use a subtle "Glassmorphism" effect with a high-saturation blur to maintain the airy feeling while ensuring content remains legible.

## Shapes
The shape language is "Soft-Modern." While the brand is clean and sharp, rigid 90-degree angles can feel too aggressive for a beauty studio.

- Use **Level 1 (Soft)** rounding (4px) for most interactive elements. This is enough to take the "edge" off while maintaining a sophisticated, geometric silhouette. 
- Image containers should remain perfectly sharp (0px) to reinforce the editorial photography style.

## Components
- **Buttons:** Use a "Ghost" style for secondary actions (thin 1px border) and a "Solid Charcoal" style for primary CTAs. Typography inside buttons should use the `label-sm` style.
- **Inputs:** Minimalist bottom-border only or a very light 4-sided border. The label should float above in `label-sm` style.
- **Cards:** No shadows. Use a subtle background color shift (e.g., from `#FAF9F6` to `#F5F2ED`) on hover.
- **Chips/Tags:** Small, pill-shaped or rectangular with very light neutral backgrounds.
- **Dividers:** Extremely thin (0.5px), using the tertiary color, often spanning only a portion of the container width to suggest structure without closing it off.
- **Specialty Component - "The Treatment Card":** A vertical card layout for services that features a sharp-edged photo at the top followed by `headline-md` and `body-md` text with generous internal padding.